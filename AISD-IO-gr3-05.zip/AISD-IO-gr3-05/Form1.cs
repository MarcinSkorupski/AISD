namespace AISD_IO_gr3_05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnNWP_Click(object sender, EventArgs e)
        {

        }

        public void NWP(String ciag1, String ciag2)
        {
            int[,] tab = new int[ciag1.Length, ciag2.Length];
            for (int i = 1; i < tab.GetLength(0); i++)
            {
                for (int j = 1; j < tab.GetLength (1); j++)
                {
                    if (ciag1[i] == ciag2[j])
                        tab[i, j] = tab[i - 1, j - 1];
                    else if (tab[i - 1, j] > tab[i, j - 1])
                        tab[i, j] = tab[i - 1, j];
                    else
                        tab[i, j] = tab[i, j - 1];
                }
            }
        }
    }
}