namespace AISD_IO_gr3_01
{
    /*public class List
    {
        int value;
        //List* prev;
        //List* next;
    }*/

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            int liczbaN = (int)nudLiczbaN.Value;
            ulong wynik = Fib2(liczbaN);
            MessageBox.Show(wynik.ToString());
        }

        private void btnBubbleSort_Click(object sender, EventArgs e)
        {
            int[] tab = { 3, 4, 7, 2, 5 };
            BubbleSort(tab);
            MessageBox.Show(ToString(tab));
        }

        private void btnSelectionSort_Click(object sender, EventArgs e)
        {
            int[] tab = { 3, 4, 7, 2, 5 };
            SelectionSort(tab);
            MessageBox.Show(ToString(tab));
        }

        private void btnInsertSort_Click(object sender, EventArgs e)
        {

            int[] tab = { 3, 4, 7, 2, 5 };
            InsertSort(tab);
            MessageBox.Show(ToString(tab));
        }

        private void nudLiczbaN_ValueChanged(object sender, EventArgs e)
        {

        }

        int Fib(int n)
        {
            if (n == 0)
                return 0;
            if (n == 1)
                return 1;
            return Fib(n - 1) + Fib(n - 2);
        }

        ulong Fib2(int n)
        {
            ulong[] wyrazy = new ulong[n + 2];
            wyrazy[0] = 0;
            wyrazy[1] = 1;
            for (int i = 2; i < n + 1; i++)
            {
                wyrazy[i] = wyrazy[i - 1] + wyrazy[i - 2];
            }
            return wyrazy[n];
        }

        void BubbleSort(int[] tab)
        {
            bool cbz = false;
            int temp;
            do
            {
                cbz = false;
                for (int i = 0; i < tab.Length - 1; i++)
                {
                    if (tab[i] > tab[i + 1])
                    {
                        temp = tab[i];
                        tab[i] = tab[i + 1];
                        tab[i + 1] = temp;
                        cbz = true;
                    }
                }
            } while (cbz);
            
        }

        void SelectionSort(int[] tab)
        {
            int min = 0;
            int temp;
            for (int i = 0; i < tab.Length; i++)
            {
                for (int j = i; j < tab.Length; j++)
                {
                    if (tab[min] > tab[j])
                        min = j;
                }
                temp = tab[min];
                tab[min] = tab[i];
                tab[i] = temp;
            }
        }

        void InsertSort(int[] tab)
        {
            int temp;
            for (int i = 1; i < tab.Length; i++)
            {
                temp = tab[i];
                for (int j = i; j > 0; j--)
                {
                    if (tab[j] < tab[j - 1])
                    {
                        tab[j] = tab[j - 1];
                        tab[j - 1] = temp;
                    }
                }
            }
        }

        string ToString(int[] tab)
        {
            string str = "";
            for (int i = 0; i < tab.Length; i++)
            {
                str += tab[i];
                str += ' ';
            }
            return str;
        }
    }
}