using System.ComponentModel.DataAnnotations;
using System.IO.Pipes;

namespace AISD_IO_gr3_03
{
    public partial class Form1 : Form
    {
        string napis = "";
        List<Wezel2> odwiedzone = new List<Wezel2>();
        List<Wezel2> kolejka2 = new List<Wezel2>();
        List<Wezel3> kolejka3 = new List<Wezel3>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var w1 = new Wezel(5);
            var w2 = new Wezel(2);
            var w3 = new Wezel(1);
            var w4 = new Wezel(3);
            var w5 = new Wezel(4);
            var w6 = new Wezel(6);
            w1.dzieci.Add(w2);
            w1.dzieci.Add(w3);
            w1.dzieci.Add(w4);
            w2.dzieci.Add(w5);
            w2.dzieci.Add(w6);

            napis = "";
            A(w1);
            MessageBox.Show(napis);
        }
        void A(Wezel w)
        {
            napis += (w.wartosc.ToString() + " ");
            foreach (var dziecko in w.dzieci)
                A(dziecko);
        }

        private void btnGraf_Click(object sender, EventArgs e)
        {
            var w1 = new Wezel2(4);
            var w2 = new Wezel2(1);
            var w3 = new Wezel2(6);
            var w4 = new Wezel2(3);
            var w5 = new Wezel2(7);
            var w6 = new Wezel2(5);
            var w7 = new Wezel2(2);
            w1.sasiedzi.Add(w2);
            w2.sasiedzi.Add(w1);
            w2.sasiedzi.Add(w3);
            w2.sasiedzi.Add(w4);
            w3.sasiedzi.Add(w2);
            w3.sasiedzi.Add(w4);
            w3.sasiedzi.Add(w6);
            w3.sasiedzi.Add(w7);
            w4.sasiedzi.Add(w2);
            w4.sasiedzi.Add(w3);
            w4.sasiedzi.Add(w5);
            w5.sasiedzi.Add(w4);
            w5.sasiedzi.Add(w7);
            w6.sasiedzi.Add(w3);
            w6.sasiedzi.Add(w7);
            w7.sasiedzi.Add(w3);
            w7.sasiedzi.Add(w5);
            w7.sasiedzi.Add(w6);

            napis = "";
            DFS(w2);
            MessageBox.Show(napis);
        }

        void DFS(Wezel2 w)
        {
            napis += (w.wartosc.ToString() + " ");
            odwiedzone.Add(w);
            foreach(var sasiad in w.sasiedzi)
            {
                if (!odwiedzone.Contains(sasiad))
                {
                    DFS(sasiad);
                }
            }
        }

        void BFS(Wezel2 w)
        {
            kolejka2.Clear();
            kolejka2.Add(w);
            foreach (var wezel in kolejka2)
            {
                foreach(var sasiad in wezel.sasiedzi)
                {
                    if (!kolejka2.Contains(sasiad))
                        kolejka2.Add(sasiad);
                }
            }
        }

        void BFS(Wezel3 w)
        {
            napis += (w.wartosc.ToString() + " ");
            kolejka3.Add(w);
            int length = 1;
            for (int i = 0; i < length; i++)
            {
                var temp = kolejka3[i];
                if (temp.lewe != null)
                {
                    kolejka3.Add(temp.lewe);
                    length++;
                }
                if (temp.prawe != null)
                {
                    kolejka3.Add(temp.prawe);
                    length++;
                }
            }
            foreach (var wezel in kolejka3)
            {
                MessageBox.Show(wezel.ToString());
            }
        }

        private void btnDrzewoBinarne_Click(object sender, EventArgs e)
        {
            int[] wezly = { 5, 7, 4, 6, 3, 1, 2, 8, 1, 7, 13, 0, 3 };
            DrzewoBinarne drzewoBin = new DrzewoBinarne(wezly[0]);
            for (int i = 1; i < wezly.Length; i++)
            {
                drzewoBin.Add(wezly[i]);
            }
            BFS(drzewoBin.korzen);
        }
    }

    public class Wezel
    {
        public int wartosc;
        public List<Wezel> dzieci = new List<Wezel>();

        public Wezel(int liczba)
        {
            this.wartosc = liczba;
        }
    }

    public class Wezel2
    {
        public int wartosc;
        public List<Wezel2> sasiedzi = new List<Wezel2>();

        public Wezel2(int liczba)
        {
            this.wartosc = liczba;
        }
    }

    public class Wezel3
    {
        public int wartosc;
        public Wezel3 rodzic;
        public Wezel3 lewe;
        public Wezel3 prawe;

        public Wezel3(int liczba)
        {
            this.wartosc = liczba;
        }

        override public string ToString()
        {
            return wartosc.ToString();
        }

        public int GetLiczbaDzieci()
        {
            int wynik = 0;
            if (this.lewe != null)
                ++wynik;
            if (this.prawe != null)
                ++wynik;
            return wynik;
        }
    }

    public class DrzewoBinarne
    {
        public Wezel3 korzen;
        public int liczbaWezlow;

        public DrzewoBinarne(int liczba)
        {
            this.korzen = new Wezel3(liczba);
            this.liczbaWezlow = 1;
        }

        public void Add(int liczba)
        {
            var rodzic = this.ZnajdzRodzica(liczba);
            var dziecko = new Wezel3(liczba);
            dziecko.rodzic = rodzic;
            if (liczba < rodzic.wartosc)
                rodzic.lewe = dziecko;
            else
                rodzic.prawe = dziecko;
            liczbaWezlow++;
        }

        public Wezel3 ZnajdzRodzica(int liczba)
        {
            Wezel3 w = korzen;
            while (true)
            {
                if (liczba < w.wartosc)
                {
                    if (w.lewe != null)
                        w = w.lewe;
                    else
                        return w;
                }
                else
                {
                    if (w.prawe != null)
                        w = w.prawe;
                    else
                        return w;
                }
            }
        }
        public Wezel3 Znajdz(int liczba)
        {
            Wezel3 w = korzen;
            while (true)
            {
                if (liczba == w.wartosc)
                    return w;
                if (liczba < w.wartosc)
                {
                    if (w.lewe != null)
                        w = w.lewe;
                    else
                        return null;
                }
                else
                {
                    if (w.prawe != null)
                        w = w.prawe;
                    else
                        return null;
                }
            }
        }

        public Wezel3 ZnajdzMin(Wezel3 w)
        {
            while (w.lewe != null)
            {
                w = w.lewe;
            }
            return w;
        }

        public Wezel3 ZnajdzMax(Wezel3 w)
        {
            while (w.prawe != null)
            {
                w = w.prawe;
            }
            return w;
        }

        public Wezel3 Nastepnik(Wezel3 w)
        {
            if (w.prawe != null)
                return this.ZnajdzMin(w.prawe);
            while (w.rodzic != null)
            {
                if (w.rodzic.lewe == w)
                    return w.rodzic;
                w = w.rodzic;
            }
            return null;
        }

        public Wezel3 Poprzednik(Wezel3 w)
        {
            if (w.lewe != null)
                return this.ZnajdzMax(w.lewe);
            while (w.rodzic != null)
            {
                if (w.rodzic.prawe == w)
                    return w.rodzic;
                w = w.rodzic;
            }
            return null;
        }

        public Wezel3 Usun(Wezel3 w)
        {
            switch(w.GetLiczbaDzieci())
            {
                case 0:
                    w = this.UsunGdy0Dzieci(w);
                    break;
                case 1:
                    w = this.UsunGdy1Dziecko(w);
                    break;
                case 2:
                    w = this.UsunGdy2Dzieci(w);
                    break;
            }
            return w;
        }

        public Wezel3 UsunGdy0Dzieci(Wezel3 w)
        {
            if (w.rodzic == null)
            {
                this.korzen = null;
                return w;
            }
            if (w.rodzic.lewe == w)
                w.rodzic.lewe = null;
            else
                w.rodzic.prawe = null;
            w.rodzic = null;
            return w;
        }

        public Wezel3 UsunGdy1Dziecko(Wezel3 w)
        {
            Wezel3 dziecko = null;
            if (w.lewe != null)
            {
                dziecko = w.lewe;
                w.lewe = null;
            }
            else
            {
                dziecko = w.prawe;
                w.prawe = null;
            }
            dziecko.rodzic = w.rodzic;

            if (w.rodzic == null)
                this.korzen = dziecko;
            else if (w.rodzic.lewe == w)
                w.rodzic.lewe = dziecko;
            else
                w.rodzic.prawe = dziecko;
            w.rodzic = null;
            return w;
        }

        public Wezel3 UsunGdy2Dzieci(Wezel3 w)
        {
            var zamiennik = this.Nastepnik(w);
            zamiennik = this.Usun(zamiennik);
            if (w.rodzic == null)
                this.korzen = zamiennik;
            else
            {
                zamiennik.rodzic = w.rodzic;
                if (w.rodzic.lewe == w)
                    w.rodzic.lewe = zamiennik;
                else
                    w.rodzic.prawe = zamiennik;
            }
            return w;
        }
    }
}