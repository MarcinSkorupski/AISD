﻿namespace AISD_IO_gr3_03
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDrzewo = new System.Windows.Forms.Button();
            this.btnGraf = new System.Windows.Forms.Button();
            this.btnDrzewoBinarne = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnDrzewo
            // 
            this.btnDrzewo.Location = new System.Drawing.Point(228, 72);
            this.btnDrzewo.Name = "btnDrzewo";
            this.btnDrzewo.Size = new System.Drawing.Size(75, 23);
            this.btnDrzewo.TabIndex = 0;
            this.btnDrzewo.Text = "Drzewo";
            this.btnDrzewo.UseVisualStyleBackColor = true;
            this.btnDrzewo.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnGraf
            // 
            this.btnGraf.Location = new System.Drawing.Point(435, 72);
            this.btnGraf.Name = "btnGraf";
            this.btnGraf.Size = new System.Drawing.Size(75, 23);
            this.btnGraf.TabIndex = 1;
            this.btnGraf.Text = "Graf";
            this.btnGraf.UseVisualStyleBackColor = true;
            this.btnGraf.Click += new System.EventHandler(this.btnGraf_Click);
            // 
            // btnDrzewoBinarne
            // 
            this.btnDrzewoBinarne.Location = new System.Drawing.Point(354, 174);
            this.btnDrzewoBinarne.Name = "btnDrzewoBinarne";
            this.btnDrzewoBinarne.Size = new System.Drawing.Size(75, 23);
            this.btnDrzewoBinarne.TabIndex = 2;
            this.btnDrzewoBinarne.Text = "DrzewoBinarne";
            this.btnDrzewoBinarne.UseVisualStyleBackColor = true;
            this.btnDrzewoBinarne.Click += new System.EventHandler(this.btnDrzewoBinarne_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDrzewoBinarne);
            this.Controls.Add(this.btnGraf);
            this.Controls.Add(this.btnDrzewo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Button btnDrzewo;
        private Button btnGraf;
        private Button btnDrzewoBinarne;
    }
}