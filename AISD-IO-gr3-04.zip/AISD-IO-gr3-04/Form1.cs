namespace AISD_IO_gr3_04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }


    public class Graf
    {
        public List<Krawedz> krawedzie;
        public List<Wezel4> wierzcholki;
        public Dictionary<Wezel4, Element> tabela;

        public List<Wezel4> ZwrocSasiadow(Wezel4 w)
        {
            var sasiedzi = new List<Wezel4>();
            foreach (Krawedz k in krawedzie)
            {
                if (k.poczatek == w)
                    sasiedzi.Add(k.koniec);
                if (k.koniec == w)
                    sasiedzi.Add(k.poczatek);
            }
            return sasiedzi;
        }

        public void ZnajdzNajkrotszeDrogi(Wezel4 w)
        {
            tabela = new Dictionary<Wezel4, Element>();

            foreach(Wezel4 wier in wierzcholki)
            {
                if (wier == w)
                    tabela.Add(wier, new Element(0));
                else
                    tabela.Add(wier, new Element());
            }

            var min = w;

            while(true)
            {
                tabela[min].czyUstalone = true;
            }
        }
    }

    public class Krawedz
    {
        public int waga;
        public Wezel4 poczatek;
        public Wezel4 koniec;
    }

    public class Wezel4
    {
        public int wartosc;
        //public List<Krawedz> listaKrawedzi;
    }

    public class Element
    {
        public int dystans;
        public Wezel4 poprzednik;
        public bool czyUstalone;

        public Element() : this(-1) { }
        public Element(int dystans)
        {
            this.dystans = dystans;
            poprzednik = null;
            czyUstalone = false;
        }
    }
}

//var wyniik = lista.Where(e => e % 2 == 0).ToList();
//var wynik = tabelka.OrderBy(item => item.Value.dystans).First();