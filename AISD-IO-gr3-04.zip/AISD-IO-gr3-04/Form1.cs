using System.Security.Permissions;

namespace AISD_IO_gr3_04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }


    public class Graf
    {
        public List<Krawedz> krawedzie;
        public List<Wezel4> wierzcholki;
        public Dictionary<Wezel4, Element> tabela;

        public Graf(Krawedz k)
        {
            this.Add(k);
        }

        public int Sprawdz(Krawedz k)
        {
            int w = 0;
            if (wierzcholki.Contains(k.poczatek))
                w++;
            if (wierzcholki.Contains(k.koniec))
                w++;
            return w;
        }

        public void Add(Krawedz k)
        {
            if (!wierzcholki.Contains(k.poczatek))
                wierzcholki.Add(k.poczatek);
            if (!wierzcholki.Contains(k.koniec))
                wierzcholki.Add(k.koniec);
            krawedzie.Add(k);
        }

        public void Join(Graf g)
        {
            foreach(Krawedz k in g.krawedzie)
            {
                this.Add(k);
            }
        }

        public Graf Kruskala()
        {
            List<Graf> podgrafy = null;
            foreach(Krawedz k in krawedzie)
            {
                if (podgrafy == null)
                {
                    podgrafy.Add(new Graf(k));
                }
                else
                    foreach(Graf g in podgrafy)
                    {
                        switch(g.Sprawdz(k))
                        {
                            case 0:
                                break;
                        }
                    }
            }
        }

        public List<Wezel4> ZwrocSasiadow(Wezel4 w)
        {
            var sasiedzi = new List<Wezel4>();
            foreach (Krawedz kraw in krawedzie)
            {
                if (kraw.poczatek == w)
                    sasiedzi.Add(kraw.koniec);
                if (kraw.koniec == w)
                    sasiedzi.Add(kraw.poczatek);
            }
            return sasiedzi;
        }

        public int ZwrocWage(Wezel4 w1, Wezel4 w2)
        {
            foreach(Krawedz kraw in krawedzie)
            {
                if (kraw.poczatek == w1 && kraw.koniec == w2 ||
                    kraw.koniec == w1 && kraw.poczatek == w2)
                    return kraw.waga;
            }
            return 0;
        }

        public void ZnajdzNajkrotszeDrogi(Wezel4 w)
        {
            tabela = new Dictionary<Wezel4, Element>();

            foreach(Wezel4 wier in wierzcholki)
            {
                if (wier == w)
                    tabela.Add(wier, new Element(0));
                else
                    tabela.Add(wier, new Element());
            }

            var temp = w;

            while(true)
            {
                var sasiedzi = ZwrocSasiadow(temp);
                foreach (Wezel4 sasiad in sasiedzi)
                {
                    if (!tabela[sasiad].czyUstalone)
                    {
                        tabela[sasiad].dystans = tabela[temp].dystans + ZwrocWage(temp, sasiad);
                    }
                }
                tabela[temp].czyUstalone = true;
            }
        }
    }

    public class Krawedz
    {
        public int waga;
        public Wezel4 poczatek;
        public Wezel4 koniec;
    }

    public class Wezel4
    {
        public int wartosc;
        //public List<Krawedz> listaKrawedzi;
    }

    public class Element
    {
        public int dystans;
        public Wezel4 poprzednik;
        public bool czyUstalone;

        public Element() : this(-1) { }
        public Element(int dystans)
        {
            this.dystans = dystans;
            poprzednik = null;
            czyUstalone = false;
        }
    }
}

//var wyniik = lista.Where(e => e % 2 == 0).ToList();
//var wynik = tabelka.OrderBy(item => item.Value.dystans).First();