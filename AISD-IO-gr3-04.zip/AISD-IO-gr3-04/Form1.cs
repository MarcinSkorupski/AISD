namespace AISD_IO_gr3_04
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void btnDijkstra_Click(object sender, EventArgs e)
        {
            List<Wezel4> wierzcholki = new List<Wezel4>();
            List<Krawedz> krawedzie = new List<Krawedz>();

            for (int i = 0; i <= 5; i++)
            {
                wierzcholki.Add(new Wezel4(i));
            }

            krawedzie.Add(new Krawedz(3, wierzcholki[0], wierzcholki[1]));
            krawedzie.Add(new Krawedz(6, wierzcholki[0], wierzcholki[5]));
            krawedzie.Add(new Krawedz(3, wierzcholki[0], wierzcholki[4]));
            krawedzie.Add(new Krawedz(1, wierzcholki[1], wierzcholki[2]));
            krawedzie.Add(new Krawedz(4, wierzcholki[1], wierzcholki[3]));
            krawedzie.Add(new Krawedz(1, wierzcholki[2], wierzcholki[5]));
            krawedzie.Add(new Krawedz(3, wierzcholki[2], wierzcholki[3]));
            krawedzie.Add(new Krawedz(2, wierzcholki[5], wierzcholki[4]));
            krawedzie.Add(new Krawedz(1, wierzcholki[5], wierzcholki[3]));

            Graf graf = new Graf(krawedzie, wierzcholki);


            graf.ZnajdzNajkrotszeDrogi(wierzcholki[0]);
            graf.PokazTabele();
        }

        private void btnKruskal_Click(object sender, EventArgs e)
        {
            List<Wezel4> wierzcholki = new List<Wezel4>();
            List<Krawedz> krawedzie = new List<Krawedz>();

            for (int i = 0; i <= 7; i++)
            {
                wierzcholki.Add(new Wezel4(i));
            }

            krawedzie.Add(new Krawedz(1, wierzcholki[4], wierzcholki[6]));
            krawedzie.Add(new Krawedz(2, wierzcholki[4], wierzcholki[5]));
            krawedzie.Add(new Krawedz(3, wierzcholki[2], wierzcholki[7]));
            krawedzie.Add(new Krawedz(3, wierzcholki[0], wierzcholki[6]));
            krawedzie.Add(new Krawedz(4, wierzcholki[2], wierzcholki[4]));
            krawedzie.Add(new Krawedz(5, wierzcholki[0], wierzcholki[1]));
            krawedzie.Add(new Krawedz(5, wierzcholki[2], wierzcholki[6]));
            krawedzie.Add(new Krawedz(6, wierzcholki[1], wierzcholki[5]));
            krawedzie.Add(new Krawedz(6, wierzcholki[5], wierzcholki[6]));
            krawedzie.Add(new Krawedz(7, wierzcholki[1], wierzcholki[7]));
            krawedzie.Add(new Krawedz(8, wierzcholki[1], wierzcholki[4]));
            krawedzie.Add(new Krawedz(8, wierzcholki[3], wierzcholki[6]));
            krawedzie.Add(new Krawedz(9, wierzcholki[0], wierzcholki[3]));
            krawedzie.Add(new Krawedz(9, wierzcholki[1], wierzcholki[2]));
            krawedzie.Add(new Krawedz(9, wierzcholki[2], wierzcholki[3]));
            krawedzie.Add(new Krawedz(9, wierzcholki[6], wierzcholki[7]));

            Graf graf = new Graf(krawedzie, wierzcholki);


            Graf drzewo = graf.Kruskala();
            drzewo.PokazGraf();
        }
    }


    public class Graf
    {
        public List<Krawedz> krawedzie;
        public List<Wezel4> wierzcholki;
        public Dictionary<Wezel4, Element> tabela;

        public Graf(List<Krawedz> krawedzie, List<Wezel4> wierzcholki)
        {
            this.krawedzie = krawedzie.OrderBy(k => k.waga).ToList();
            this.wierzcholki = wierzcholki;
            
        }

        //------------------------------------
        //Metody do algorytmu Dijkstry

        public List<Wezel4> ZwrocSasiadow(Wezel4 w)
        {
            var sasiedzi = new List<Wezel4>();
            foreach (Krawedz kraw in krawedzie)
            {
                if (kraw.poczatek == w)
                    sasiedzi.Add(kraw.koniec);
                if (kraw.koniec == w)
                    sasiedzi.Add(kraw.poczatek);
            }
            return sasiedzi;
        }

        public int ZwrocWage(Wezel4 w1, Wezel4 w2)
        {
            foreach (Krawedz kraw in krawedzie)
            {
                if (kraw.poczatek == w1 && kraw.koniec == w2 ||
                    kraw.koniec == w1 && kraw.poczatek == w2)
                    return kraw.waga;
            }
            return 0;
        }

        public void ZnajdzNajkrotszeDrogi(Wezel4 w)
        {
            tabela = new Dictionary<Wezel4, Element>();

            foreach (Wezel4 wier in wierzcholki)
            {
                if (wier == w)
                    tabela.Add(wier, new Element(0, true));
                else
                    tabela.Add(wier, new Element());
            }

            Wezel4 temp = w;

            while (tabela.Where(e => !e.Value.czyUstalone).Count() > 0)
            {
                foreach (Wezel4 sasiad in ZwrocSasiadow(temp))
                {
                    int nowyDystans = tabela[temp].dystans + ZwrocWage(temp, sasiad);
                    if (!tabela[sasiad].czyUstalone && tabela[sasiad].dystans > nowyDystans)
                    {
                        tabela[sasiad].dystans = nowyDystans;
                        tabela[sasiad].poprzednik = temp;
                    }
                }
                temp = tabela.Where(e => !e.Value.czyUstalone).OrderBy(e => e.Value.dystans).First().Key;
                tabela[temp].czyUstalone = true;
            }
        }

        public void PokazTabele()
        {
            String line1 = "wierzcho�ek  ";
            String line2 = "dystans         ";
            String line3 = "poprzednik  ";
            foreach (Wezel4 w in tabela.Keys)
            {
                line1 += "   " + w.wartosc.ToString() + "   ";
                line2 += "   " + tabela[w].dystans.ToString() + "   ";
                if (w.wartosc == 0)
                    line3 += " null ";
                else
                    line3 += "   " + tabela[w].poprzednik.wartosc.ToString() + "   ";
            }

            MessageBox.Show(line1 + "\n" + line2 + "\n" + line3);
        }


        //------------------------------------
        //Metody do algorytmu Kruskala

        public Graf(Krawedz k)
        {
            krawedzie = new List<Krawedz>();
            wierzcholki = new List<Wezel4>();
            Add(k);
        }

        public int Sprawdz(Krawedz k)
        {
            int w = 0;
            if (!wierzcholki.Contains(k.poczatek))
                w++;
            if (!wierzcholki.Contains(k.koniec))
                w++;
            return w;
        }

        public void Add(Krawedz k)
        {
            if (!wierzcholki.Contains(k.poczatek))
                wierzcholki.Add(k.poczatek);
            if (!wierzcholki.Contains(k.koniec))
                wierzcholki.Add(k.koniec);
            krawedzie.Add(k);
        }

        public void Join(Graf g)
        {
            foreach (Krawedz k in g.krawedzie)
            {
                Add(k);
            }
        }

        public Graf Kruskala()
        {
            List<Graf> podgrafy = new List<Graf>();
            podgrafy.Add(new Graf(krawedzie[0]));
            for (int i = 1; i < krawedzie.Count() && podgrafy[0].wierzcholki.Count() < wierzcholki.Count(); i++)
            {
                DodajDoPodgrafow(podgrafy, krawedzie[i]);
            }
            return podgrafy[0];
        }

        public void DodajDoPodgrafow(List<Graf> podgrafy, Krawedz k)
        {
            Graf added = null;
            foreach (Graf g in podgrafy)
                {
                switch (g.Sprawdz(k))
                {
                    case 0:
                        return;
                    case 1:
                        if (added == null)
                        {
                            g.Add(k);
                            added = g;
                            break;
                        }
                        else
                        {
                            added.Join(g);
                            podgrafy.Remove(g);
                            return;
                        }
                    case 2:
                    default:
                        break;
                }
            }
            if (added == null)
                podgrafy.Add(new Graf(k));
        }

        public void PokazGraf()
        {
            String graf = "waga   kraw�d�\n";
            foreach(Krawedz k in krawedzie)
            {
                graf += "   " + k.waga.ToString() + "           "
                    + k.poczatek.wartosc.ToString() + "-"
                    + k.koniec.wartosc.ToString() + "\n";
            }
            MessageBox.Show(graf);
        }
    }

    //------------------------------------

    public class Krawedz
    {
        public int waga;
        public Wezel4 poczatek;
        public Wezel4 koniec;

        public Krawedz(int waga, Wezel4 poczatek, Wezel4 koniec)
        {
            this.waga = waga;
            this.poczatek = poczatek;
            this.koniec = koniec;
        }
    }

    public class Wezel4
    {
        public int wartosc;

        public Wezel4(int wartosc)
        {
            this.wartosc = wartosc;
        }
    }

    public class Element
    {
        public int dystans;
        public Wezel4 poprzednik;
        public bool czyUstalone;

        public Element() : this(int.MaxValue, false) { }
        public Element(int dystans, bool czyUstalone)
        {
            this.dystans = dystans;
            poprzednik = null;
            this.czyUstalone = czyUstalone;
        }
    }
}